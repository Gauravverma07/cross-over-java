/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.crossover.techtrial.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.util.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Gaurav.Verma
 */
public class RideTest {
    
    
    
    Ride r1,r2;
    
    
    public RideTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        
        r1 = new Ride();
        
    }
    
    @After
    public void tearDown() {
    }

    @Test
     public void testHashCode() 
     {
         
         r1.setDistance(null);
         r1.setId(null);
         r1.setStartTime(null);
         r1.setEndTime(null);
         r1.setDriver(null);
         r1.setRider(null);
         assertEquals(Math.pow(31,6),r1.hashCode(),0.0);
         
         
     }
     
     @Test
     public void testHashCode2() 
     {
         r1.setStartTime(null);
         r1.setDistance(0l);
         r1.setEndTime(null);
         r1.setId(0l);
         r1.setDriver(null);
         r1.setRider(null);
         assertEquals(Math.pow(31,6),r1.hashCode(),0);
         
         
     }
     
     @Test
     public void testEquals1()   // for same object
     {
        r1 = new Ride();
        assertTrue(r1.equals(r1));
     }
     
    @Test
     public void testEquals2()   // for 2nd object as null.
     {
        r1 = new Ride(); 
        r2 = null;
        assertFalse(r1.equals(r2));
     }
     
     @Test
     public void testEquals3()   // for objects of different classes
     {
        r1 = new Ride();
        assertFalse(r1.equals(new Person()));
     }
     
     @Test
     public void testEquals4()   // for obj1.distance=null
     {
        r1 = new Ride();
        r1.distance=null;
        r2 = new Ride();
        r2.distance=2L;
        assertFalse(r1.equals(r2));
     }
     
     @Test
     public void testEquals5()   // for obj1 and obj2 distance different
     {
        r1 = new Ride();
        r1.distance=1L;
        r2 = new Ride();
        r2.distance = 2L;
        assertFalse(r1.equals(r2));
     }
     
     @Test
     public void testEquals6()   // for obj1.driver = null
     {
        r1 = new Ride();
        r1.distance=1L;
        r1.driver = null;
        r2 = new Ride();
        r2.distance = 1L;
        r2.driver=new Person();
        assertFalse(r1.equals(r2));
     }
     
     @Test
     public void testEquals7()   // for obj1 and obj2 driver different
     {
        r1 = new Ride();
        r1.distance=1L;
        Person p1 = new Person();
        p1.id=1L;
        r1.driver = p1;
        
        r2 = new Ride();
        r2.distance = 1L;
        Person p2=new Person();
        p2.id=2L;
        r2.driver = p2;
        assertFalse(r1.equals(r2));
     }
     
     @Test
     public void testEquals8()   // for obj1 endTime null
     {
        r1 = new Ride();
        r1.distance=1L;
        r1.driver = new Person();
        r1.endTime=null;
        r2 = new Ride();
        r2.distance = 1L;
        r2.driver=new Person();
        r2.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        assertFalse(r1.equals(r2));
     }
     
     @Test
     public void testEquals9()   // for obj1 and obj2 endTime different
     {
        r1 = new Ride();
        r1.distance=1L;
        r1.driver = new Person();
        r1.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(12,45,34,15));
        r2 = new Ride();
        r2.distance = 1L;
        r2.driver=r2.driver;
        r2.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        assertFalse(r1.equals(r2));
     }
     
     @Test
     public void testEquals10()   // for obj1 id null
     {
        r1 = new Ride();
        r1.distance=1L;
        r1.driver = new Person();
        r1.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        r1.id=null;
        
        r2 = new Ride();
        r2.distance = 1L;
        r2.driver=r1.driver;
        r2.endTime=r1.endTime;
        r2.id=2L;
        
        assertFalse(r1.equals(r2));
     }
     
     @Test
     public void testEquals11()   // for obj1 and obj2 id different
     {
        r1 = new Ride();
        r1.distance=1L;
        r1.driver = new Person();
        r1.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        r1.id=1L;
        
        r2 = new Ride();
        r2.distance = 1L;
        r2.driver=r1.driver;
        r2.endTime=r1.endTime;
        r2.id=2L;
        
        assertFalse(r1.equals(r2));
     }
     
     
     @Test
     public void testEquals12()   // for obj1 rider null
     {
        r1 = new Ride();
        r1.distance=1L;
        r1.driver = new Person();
        r1.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        r1.id=1L;
        r1.rider=null;
        
        r2 = new Ride();
        r2.distance = 1L;
        r2.driver=r1.driver;
        r2.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        r2.id=1L;
        r2.rider=new Person();
        assertFalse(r1.equals(r2));
     }
     
     @Test
     public void testEquals13()   // for obj1 and obj2 rider different
     {
        r1 = new Ride();
        r1.distance=1L;
        r1.driver = new Person();
        r1.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        r1.id=1L;
        Person p1=new Person();
        p1.id=3L;
        r1.rider = p1;
        r2 = new Ride();
        r2.distance = 1L;
        r2.driver=r1.driver;
        r2.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        r2.id=1L;
        Person p2=new Person();
        p2.id=2L;
        r2.rider = p2;
        assertFalse(r1.equals(r2));
        
     }
     
     @Test
     public void testEquals14()   // for obj1 startTime null
     {
        r1 = new Ride();
        r1.distance=1L;
        r1.driver = new Person();
        r1.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        r1.id=1L;
        r1.rider=new Person();
        r1.startTime=null;
        
        r2 = new Ride();
        r2.distance = 1L;
        r2.driver=r1.driver;
        r2.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        r2.id=1L;
        r2.rider=r1.rider;
        r2.startTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,12,25,00));
        
        assertFalse(r1.equals(r2));
     }
     
     
     @Test
     public void testEquals15()   // for obj1 and obj2 startTime different
     {
        r1 = new Ride();
        r1.distance=1L;
        r1.driver = new Person();
        r1.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        r1.id=1L;
        r1.rider=new Person();
        r1.startTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,25,20,00));
        
        r2 = new Ride();
        r2.distance = 1L;
        r2.driver=r1.driver;
        r2.endTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,53,25,00));
        r2.id=1L;
        r2.rider=r1.rider;
        r2.startTime=LocalDateTime.of(LocalDate.of(2018,Month.MARCH,12),LocalTime.of(17,21,20,00));
        
        assertFalse(r1.equals(r2));
     }
       
}
