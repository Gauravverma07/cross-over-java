/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.crossover.techtrial.model;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Gaurav.Verma
 */
public class PersonTest {
    
    
    Person p,q;
    public PersonTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        p = new Person();
        q = new Person();
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     @Test
     public void testHashCode() 
     {
         int res = 1;
         p.email=null;
         p.id=null;
         p.name=null;
         p.registrationNumber=null;
         assertEquals(Math.pow(31,4),p.hashCode(),0.0);
         
         
     }
     
     @Test
     public void testHashCode2() 
     {
         p.email="";
         p.id=0l;
         p.name="";
         p.registrationNumber="";
         assertEquals(31*31*31*31,p.hashCode(),0);
         
         
     }
     
     @Test
     public void testEquals()
     {
        p.email="";
        p.id=0l;
        p.name="";
        p.registrationNumber="";
        q.email="abc@123.com";
        q.id=1l;
        q.name="gaurav";
        q.registrationNumber="r1";
        assertEquals(false,p.equals(q));
     }
}
