/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.crossover.techtrial.exceptions;

import org.junit.Assert;
import com.crossover.techtrial.repositories.PersonRepository;
import java.util.AbstractMap;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;

/**
 *
 * @author Global.Root
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class GlobalExceptionHandlerTest {
    
   MockMvc mockMvc;
   Exception exception;
   AbstractMap.SimpleEntry<String,String> response;
   private static final Logger LOG = LoggerFactory.getLogger(GlobalExceptionHandler.class);
   
  @Mock
  private GlobalExceptionHandler globalExceptionHandler;
  
  @Autowired
  private TestRestTemplate template;
  
  @Autowired
  PersonRepository personRepository;
  
  @Before
  public void setup() throws Exception {
    
     
     exception  = Mockito.mock(Exception.class);
  }
  
  @Test
  public void testHandle() throws Exception {
    
      
      //Mockito.when(LOG.error("Exception: Unable to process this request. ",exception)).
      Mockito.when(globalExceptionHandler.handle(exception)).thenReturn(ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response));
      
 ResponseEntity t = globalExceptionHandler.handle(exception);
 
LOG.error("Exception: Unable to process this request. ",exception);

response = new AbstractMap.SimpleEntry<>("message","Unable to process this request.");
    //Assert.assertEquals(globalExceptionHandler.handle(exception),t);
 
 Mockito.verify(globalExceptionHandler).handle(exception);
 //Mockito.verify(exception);
  }
     
}
