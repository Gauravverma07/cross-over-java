/**
 * 
 */
package com.crossover.techtrial.controller;

import com.crossover.techtrial.dto.PersonDTO;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.crossover.techtrial.model.Person;
import com.crossover.techtrial.repositories.PersonRepository;
import com.crossover.techtrial.service.PersonService;
import java.util.List;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

/**
 * @author kshah
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class PersonControllerTest {
  
  @Autowired
  private TestRestTemplate template;

  MockMvc mockMvc;
  
  
  @Autowired
  PersonRepository personRepository;

  Long id;

  @Mock
  private PersonController personController;
  
  @Before
  
  public void setUp() throws Exception{
      
    mockMvc = MockMvcBuilders.standaloneSetup(personController).build();
    Person person = new Person();
    person.setEmail("gauravverma07@gmail.com");
    personRepository.save(person);
    id = person.getId();
  }
  
  
  @Test
  public void testPanelShouldBeRegistered() throws Exception {
    HttpEntity<Object> person = getHttpEntity(
      "{\"name\": \"test 1\", \"email\": \"test10000000000001@gmail.com\"," 
      + " \"registrationNumber\": \"41DCT\",\"registrationDate\":\"2018-08-08T12:12:12\" }");
    ResponseEntity<Person> response = template.postForEntity(
            "/api/person",person,Person.class);
    //Delete this user
    personRepository.deleteById(response.getBody().getId());
    assertEquals("test 1", response.getBody().getName());
    assertEquals(200,response.getStatusCode().value());
  }

   @Test
  public void testGetPersonByID()  {
    ResponseEntity<Person> response = template.getForEntity("/api/person/"+id,Person.class);
    assertEquals("gauravverma07@gmail.com",response.getBody().getEmail());
  }
  
  @Test
  public void testRetrieveAllPersons()  {
    ResponseEntity<List> response = template.getForEntity("/api/person/",List.class);
    assertNotEquals(0,response.getBody().size());
  }
  
  private HttpEntity<Object> getHttpEntity(Object body) {
    HttpHeaders headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    return new HttpEntity<Object>(body, headers);
  }
  
//  @TestConfiguration
//  class MockInjectionConfiguration {
//
//    @Bean
//    public PersonService service() {
//      return Mockito.mock(PersonService.class);
//    }
//  }

}
