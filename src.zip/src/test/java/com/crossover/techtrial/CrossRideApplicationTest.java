/**
 * 
 */
package com.crossover.techtrial;

/**
 * @author crossover
 *
 */
public class CrossRideApplicationTest {
 
    
}
