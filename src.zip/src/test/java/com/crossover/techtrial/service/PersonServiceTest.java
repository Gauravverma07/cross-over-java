package com.crossover.techtrial.service;
//
//import com.crossover.techtrial.model.Person;
//import com.crossover.techtrial.repositories.PersonRepository;
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import javax.validation.ConstraintViolationException;
//import java.util.*;
//
//import static org.junit.Assert.*;
//import org.junit.Before;
//import org.junit.runner.RunWith;
//import static org.mockito.ArgumentMatchers.anyLong;
//import org.mockito.Mock;
//import static org.mockito.Mockito.when;
//import org.mockito.runners.MockitoJUnitRunner;
//import org.springframework.boot.test.context.SpringBootTest;
//
//
//@RunWith(MockitoJUnitRunner.class)
//@SpringBootTest
//public class PersonServiceTest {
//
//    @Autowired      
//    PersonRepository personRepository ;
//
//    @Autowired
//    PersonService personService;

    
    //-------------------------------- Test FindByID -------------------------------------
//    @Test
//    public void TestNotExsistReturnNull() {
//        when(personRepository.findById(2l)).thenReturn(Optional.empty());
//        assertNull(personService.findById(2l));
//    }
//
//    @Test
//    public void TestExsistReturnPerson() {
//        when(personRepository.findById(anyLong())).thenReturn(Optional.of(new Person()));
//        Person person = personService.findById(3L);
//        assertNotNull(person);
//    }
//
//    //-------------------------------- Test GetAll -------------------------------------
//    @Test
//    public void testGetAllEmpty(){
//        when(personRepository.findAll()).thenReturn(Collections.emptyList());
//        assertEquals(0,personService.getAll().size());
//    }
//
//    @Test
//    public void testGetAllHasElements(){
//        List list = Arrays.asList(new Person(),new Person(),new Person());
//        when(personRepository.findAll()).thenReturn(list);
//        assertEquals(3,personService.getAll().size());
//    }

 
//}