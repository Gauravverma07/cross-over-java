/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.crossover.techtrial.dto;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Gaurav.Verma
 */
public class TopDriverDTOTest {
    
    
    
    TopDriverDTO td;
    TopDriverDTO[] Drivers= new TopDriverDTO[10];
    TopDriverDTO[] topDrivers = new TopDriverDTO[5];
    
    public TopDriverDTOTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        
        td = new TopDriverDTO();
        
        Drivers[0] = new TopDriverDTO(); 
        Drivers[0].setName("Joseph");
        Drivers[0].setEmail("Joseph@123.com");
        Drivers[0].setMaxRideDurationInSeconds(5000L);
        Drivers[0].setTotalRideDurationInSeconds(12000L);
        Drivers[0].setAverageDistance(40.0);
        
        Drivers[1] = new TopDriverDTO();
        Drivers[1].setName("Mary");
        Drivers[1].setEmail("Mary@123.com");
        Drivers[1].setMaxRideDurationInSeconds(6000L);
        Drivers[1].setTotalRideDurationInSeconds(16000L);
        Drivers[1].setAverageDistance(53.33);
        
        Drivers[2] = new TopDriverDTO();
        Drivers[2].setName("Tiger");
        Drivers[2].setEmail("Tiger@123.com");
        Drivers[2].setMaxRideDurationInSeconds(5500L);
        Drivers[2].setTotalRideDurationInSeconds(14500L);
        Drivers[2].setAverageDistance(48.33);
        
        Drivers[3] = new TopDriverDTO();
        Drivers[3].setName("Robert");
        Drivers[3].setEmail("Robert@123.com");
        Drivers[3].setMaxRideDurationInSeconds(5700L);
        Drivers[3].setTotalRideDurationInSeconds(18800L);
        Drivers[3].setAverageDistance(62.67);
        
        
        Drivers[4] = new TopDriverDTO();
        Drivers[4].setName("Scott");
        Drivers[4].setEmail("Scott@123.com");
        Drivers[4].setMaxRideDurationInSeconds(5600L);
        Drivers[4].setTotalRideDurationInSeconds(16600L);
        Drivers[4].setAverageDistance(55.33);
        
        
        Drivers[5] = new TopDriverDTO();
        Drivers[5].setName("Daniel");
        Drivers[5].setEmail("Daniel@123.com");
        Drivers[5].setMaxRideDurationInSeconds(3200L);
        Drivers[5].setTotalRideDurationInSeconds(8800L);
        Drivers[5].setAverageDistance(29.33);
        
        
        Drivers[6] = new TopDriverDTO();
        Drivers[6].setName("Alan");
        Drivers[6].setEmail("Alan@123.com");
        Drivers[6].setMaxRideDurationInSeconds(5600L);
        Drivers[6].setTotalRideDurationInSeconds(15000L);
        Drivers[6].setAverageDistance(50.00);
        
        
        Drivers[7] = new TopDriverDTO();
        Drivers[7].setName("Craig");
        Drivers[7].setEmail("Craig@123.com");
        Drivers[7].setMaxRideDurationInSeconds(4000L);
        Drivers[7].setTotalRideDurationInSeconds(8200L);
        Drivers[7].setAverageDistance(27.33);
        
        
        Drivers[8] = new TopDriverDTO();
        Drivers[8].setName("Tim");
        Drivers[8].setEmail("Tim@123.com");
        Drivers[8].setMaxRideDurationInSeconds(3300L);
        Drivers[8].setTotalRideDurationInSeconds(8800L);
        Drivers[8].setAverageDistance(29.33);
        
        
        Drivers[9] = new TopDriverDTO();
        Drivers[9].setName("Drake");
        Drivers[9].setEmail("Drake@123.com");
        Drivers[9].setMaxRideDurationInSeconds(5400L);
        Drivers[9].setTotalRideDurationInSeconds(14300L);
        Drivers[9].setAverageDistance(47.67);
        
        
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
     @Test
     public void testTopFiveDriversWithMaximumDuration()
     {
       topDrivers[0] = Drivers[3];
       topDrivers[1] = Drivers[4];
       topDrivers[2] = Drivers[1];
       topDrivers[3] = Drivers[6]; 
       topDrivers[4] = Drivers[2];
       
       assertEquals(topDrivers[0].getName(),td.topFiveDriverswithMaximumDuration(Drivers)[0].getName());
     }
     
}
