package com.crossover.techtrial;

import com.crossover.techtrial.model.Person;
import com.crossover.techtrial.service.PersonService;
import com.crossover.techtrial.service.PersonServiceImpl;
import static java.lang.System.exit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author crossover
 *
 */
@SpringBootApplication
public class CrossRideApplication {
  
   
  public static void main(String[] args) {
       SpringApplication.run(CrossRideApplication.class,args);
  }
  
}