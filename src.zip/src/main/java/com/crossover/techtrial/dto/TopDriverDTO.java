/**
 * 
 */
package com.crossover.techtrial.dto;

import com.crossover.techtrial.model.Person;

/**
 * @author crossover
 *
 */
public class TopDriverDTO {
  
  /**
   * Constructor for TopDriverDTO
   * @param name
   * @param email
   * @param totalRideDurationInSeconds
   * @param maxRideDurationInSeconds
   * @param averageDistance
   */
  public TopDriverDTO(String name, String email, Long totalRideDurationInSeconds,
    Long maxRideDurationInSeconds,Double averageDistance) 
  {
    this.setName(name);
    this.setEmail(email);
    this.setAverageDistance(averageDistance);
    this.setMaxRideDurationInSeconds(maxRideDurationInSeconds);
    this.setTotalRideDurationInSeconds(totalRideDurationInSeconds);
    
  }
  
  public TopDriverDTO() {
    
  }
  
  private String name;
  
  private String email;
  
  private Long totalRideDurationInSeconds;
  
  private Long maxRideDurationInSeconds;
  
  private Double averageDistance;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getEmail() {
    return email;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public Long getTotalRideDurationInSeconds() {
    return totalRideDurationInSeconds;
  }

  public void setTotalRideDurationInSeconds(Long totalRideDurationInSeconds) {
    this.totalRideDurationInSeconds = totalRideDurationInSeconds;
  }

  public Long getMaxRideDurationInSeconds() {
    return maxRideDurationInSeconds;
  }

  public void setMaxRideDurationInSeconds(Long maxRideDurationInSecods) {
    this.maxRideDurationInSeconds = maxRideDurationInSecods;
  }

  public Double getAverageDistance() {
    return averageDistance;
  }

  public void setAverageDistance(Double averageDistance) {
    this.averageDistance = averageDistance;
  }
  
  public TopDriverDTO[] topFiveDriverswithMaximumDuration(TopDriverDTO[] Drivers)
  {
    int n = Drivers.length;  
    TopDriverDTO temp = null;  
     for(int i=0; i < n; i++)
     {  
       for(int j=1; j <(n-i); j++)
        {  
          if(Drivers[j-1].getTotalRideDurationInSeconds() > Drivers[j].getTotalRideDurationInSeconds())
             {  
                      //swap elements  
                      temp = Drivers[j-1];  
                          Drivers[j-1] = Drivers[j];  
                                 Drivers[j] = temp;  
             }  
                          
        }
      }
     
     TopDriverDTO[] topFive=new TopDriverDTO[5];
     for(int i=0;i<=4;i++)
     {
       topFive[i]=Drivers[9-i];   
     }
      
     for(int i=0;i<=4;i++)
     {
         System.out.println("The Avergae Distance Covered by the "+i+"th driver"+topFive[i].getAverageDistance());
     }
     return topFive;
  }
  
}
