 /**
 * 
 */
package com.crossover.techtrial.service;

import com.crossover.techtrial.dto.TopDriverDTO;
import com.crossover.techtrial.exceptions.GlobalExceptionHandler;
import com.crossover.techtrial.model.Person;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.crossover.techtrial.model.Ride;
import com.crossover.techtrial.repositories.RideRepository;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.StreamSupport;
import org.springframework.data.domain.PageRequest;

/**
 * @author crossover
 *
 */


@Service
public class RideServiceImpl implements RideService{

  @Autowired
  RideRepository rideRepository;
  
  static int c=0;
  
  
  public Ride save(Ride ride) throws GlobalExceptionHandler{
    
      Long driver_Id = ride.getDriver().getId();
      Long rider_Id = ride.getRider().getId();
      
      PersonService personService = new PersonServiceImpl();
      Person driver=personService.findById(driver_Id);
      Person rider=personService.findById(rider_Id);
      if(driver==null)
      {
          System.out.println("Driver is not registered");
          return null;
      }
      if(rider==null)
      {
          System.out.println("Rider is not registered.");
          return null;
      }
      
      //check date condition
    LocalDateTime endTime =   ride.getEndTime();
    LocalDateTime startTime = ride.getStartTime();

    if(endTime.isBefore(startTime) || endTime.isEqual(startTime))
      throw new RuntimeException("Error in DateTime");

    return rideRepository.save(ride);
  }
  
  @Override
  public Ride findById(Long rideId) {
    Optional<Ride> optionalRide = rideRepository.findById(rideId);
    if(optionalRide.isPresent()) {
      return optionalRide.get();
    }
    else return null;
  }

  @Override
  public List<TopDriverDTO> findTopDriver(LocalDateTime start , LocalDateTime end , Long count){

   Optional<List> topDriver = rideRepository.findTopDriver(start, end,PageRequest.of(0,count.intValue()));

    if(!topDriver.isPresent())
      return null;

    List<TopDriverDTO> topDriverDTOS = new ArrayList<>();
    List list = topDriver.get();

    for (int i = 0; i < list.size(); i++) 
    {
      Object [] ob = (Object[]) list.get(i);

      Person person = (Person) ob[0];
      Long distance = (Long) ob[1];
      

      Iterable<Ride> itr = rideRepository.findAllByDriver(person);
       
      long max = StreamSupport.stream(itr.spliterator(), false)
              .mapToLong(r -> r.getStartTime().until(r.getEndTime(), ChronoUnit.SECONDS))
              .max().getAsLong();

      double average = StreamSupport.stream(itr.spliterator(), false)
              .mapToLong(r -> r.getStartTime().until(r.getEndTime(), ChronoUnit.SECONDS))
              .average().getAsDouble();

      topDriverDTOS.add(new TopDriverDTO(person.getName(),person.getEmail(),distance,max,average));
    }



  return topDriverDTOS;


  }

  

}
